module.exports = {
	url : 'mongolslave.cloudapp.net:27017/Opgave2Db'
}