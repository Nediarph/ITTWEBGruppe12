﻿//var OblOpgave3 = angular.module("OblOpgave3", ['ui.router', 'ui.bootstrap']);

//OblOpgave3.config(function($stateProvider, $urlRouterProvider) {
//    $urlRouterProvider.otherwise('/home');

//    $stateProvider
//        .state('home', {
//            url: '/home',
//            templateUrl: './views/partial-home.html',
//            controller: 'homeController'
//        })
//    .state('login', {
//        url: '/login',
//        templateUrl: './views/partial-login.html',
//        controller: 'loginController'

//        })
//    .state('register', {
//        url: '/register',
//        templateUrl: './views/partial-register.html',
//        controller: 'registerController'
//    })
//    .state('workout', {
//        url: '/workout',
//        templateUrl: './views/partial-workout.html',
//        controller: 'workoutController'
//        });

//});